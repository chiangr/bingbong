import { writeFile } from 'node:fs/promises';
import hero from '../src/sections/01-promise.js';
import pet from '../src/sections/02-pet.js';
import boop from '../src/sections/03-boop.js';
import hold from '../src/sections/04-hold.js';
import creature from '../src/sections/05-creature.js';
import halo from '../src/sections/06-halo.js';
import object from '../src/sections/07-object.js';
import quiet from '../src/sections/08-quiet.js';
import size from '../src/sections/09-scale.js';
import details from '../src/sections/10-specifications.js';
const sections=[hero,pet,boop,hold,creature,halo,object,quiet,size,details];
const escape=s=>s.replaceAll('&','&amp;').replaceAll('"','&quot;');
const html=`<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#120f0d"><meta name="color-scheme" content="dark light"><title>bingbong — You turn it. They feel it.</title><meta name="description" content="A small cellular keychain, made for two. Turn to pet. Press to boop. Hold to be there. No phone, no app, nothing to set up."><link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="preload" href="/fonts/bricolage-grotesque.woff2" as="font" type="font/woff2" crossorigin><link rel="preload" href="/renders/hello.webp" as="image" fetchpriority="high" media="(min-width:700px)"><link rel="preload" href="/renders/hello-mobile.webp" as="image" fetchpriority="high" media="(max-width:699px)"><link rel="stylesheet" href="/src/style.css"></head>
<body>
<a class="skip-link" href="#main">Skip to the story</a>
<header class="site-header"><a class="wordmark" href="#hello" aria-label="bing·bong home">bing<span class="brand-dot">·</span>bong</a><nav aria-label="Main navigation"><a href="#pet">How it feels</a><a href="#object">The little things</a><a href="#details">The details</a></nav><a class="nav-try" href="#boop">Try a boop <span aria-hidden="true">↗</span></a></header>
<aside aria-label="Interactive product"><div class="scene-stage" id="scene-stage" role="group" aria-label="${escape(hero.alt)}"><img class="hero-still hero-desktop" src="/renders/hello.webp" width="1200" height="1100" alt="" fetchpriority="high"><img class="hero-still hero-mobile" src="/renders/hello-mobile.webp" width="390" height="363" alt="" fetchpriority="high"><div class="scene-canvas" id="scene-canvas"></div><div class="scene-note"><span class="tiny-spark" aria-hidden="true">✳</span><span id="scene-note">${hero.annotation}</span></div><div class="pair-label yours"><span></span>YOURS</div><div class="pair-label theirs"><span></span>THEIRS</div><div class="travel-line" aria-hidden="true"><i></i></div><div class="size-rule"><span>95 mm</span></div><button id="crown-target" class="crown-target" aria-label="Give it a turn. Crown: drag or use arrow keys to turn; Enter to boop; hold Space for presence" aria-describedby="crown-help"><span class="crown-hint">Give it a turn <span aria-hidden="true">↻</span></span></button></div>
<p class="sr-only" id="crown-help">Left and right arrows turn by one detent. Enter sends one boop. Hold Space to share presence, then release.</p>
</aside><aside class="chapter-progress" aria-label="Story progress"><span id="chapter-number">01</span><div class="progress-track"><i id="progress-fill"></i></div><span>10</span></aside>
<main id="main">${sections.map((section,index)=>`<section id="${section.id}" class="story-section ${index===0?'hero':''} ${section.id==='halo'?'dark-chapter':''}" data-index="${index}" data-label="${escape(section.label)}" data-alt="${escape(section.alt)}" data-note="${escape(section.annotation)}" aria-labelledby="title-${section.id}"><div class="section-inner"><div class="section-copy"><p class="eyebrow"><span aria-hidden="true"></span>${section.eyebrow}</p><${index===0?'h1':'h2'} id="title-${section.id}">${section.title}</${index===0?'h1':'h2'}><p class="description">${section.description}</p>${section.extra}</div><img class="section-still" src="/renders/${section.id}.webp" width="1200" height="1100" alt="${escape(section.alt)}" loading="${index===0?'eager':'lazy'}"></div>${index===0?'<div class="hero-bottom"><a href="#pet"><span class="scroll-line" aria-hidden="true"></span>SCROLL A LITTLE CLOSER</a><span>CELLULAR KEYCHAINS, MADE FOR TWO</span><span class="hero-edition">THE BINGBONG EXPERIENCE / 001</span></div>':''}</section>`).join('')}
</main><footer><a class="wordmark" href="#hello">bing<span class="brand-dot">·</span>bong</a><p>A little way to say, I’m here.</p><span>Target specifications. Nothing measured yet.</span></footer>
<div class="utility-bar interactive" role="region" aria-label="Experience controls"><button id="sound-toggle" aria-pressed="false" aria-label="Sound off. Turn click sound on."><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h4l5-4v14l-5-4H4zM17 9l5 6m0-6-5 6"/></svg><span>Sound off</span></button><span id="chapter-name">THE PROMISE</span></div>
<div id="gesture-announcement" class="sr-only" role="status" aria-live="polite"></div>
<script type="module" src="/src/main.js"></script>
</body></html>`;
await writeFile('index.html',html);
console.log('Static page generated: 10 sections, all text available without JavaScript.');
