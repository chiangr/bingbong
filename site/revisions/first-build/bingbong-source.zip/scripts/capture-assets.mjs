import { chromium } from '@playwright/test';
import { writeFile,mkdir } from 'node:fs/promises';
import sharp from 'sharp';
import { poses } from '../src/timeline.js';
const names=['hello','pet','boop','hold','creature','halo','object','quiet','size','details'];
const metadata={};
const browser=await chromium.launch({channel:'chrome',headless:true,args:['--enable-webgl','--ignore-gpu-blocklist']});
const page=await browser.newPage({viewport:{width:1200,height:1100},deviceScaleFactor:1});
await page.goto('http://127.0.0.1:5173/render-lab.html');await page.waitForSelector('body[data-ready="true"]');
await page.addStyleTag({content:'h1,p,.mascot{display:none!important}html,body{background:transparent!important}'});
for(let i=0;i<names.length;i++){
  await page.evaluate(pose=>window.scene.setFrame({...pose,reduced:true}),poses[i]);await page.waitForTimeout(80);
  const data=await page.evaluate(()=>window.scene.renderer.domElement.toDataURL('image/png'));
  const buffer=Buffer.from(data.split(',')[1],'base64');await sharp(buffer).webp({quality:88,alphaQuality:90}).toFile(`public/renders/${names[i]}.webp`);
  metadata[names[i]]={width:1200,height:1100,crown:await page.evaluate(()=>window.scene.projectCrown())};
}
await page.setViewportSize({width:390,height:363});await page.waitForTimeout(100);
for(let i=0;i<names.length;i++){
  const pose={...poses[i],reduced:true};if(pose.pair)pose.y=17;if(i===8)pose.scale=(95/25.4*96)/(390/112*95);
  await page.evaluate(pose=>window.scene.setFrame(pose),pose);await page.waitForTimeout(50);
  const data=await page.evaluate(()=>window.scene.renderer.domElement.toDataURL('image/png'));await sharp(Buffer.from(data.split(',')[1],'base64')).webp({quality:90}).toFile(`public/renders/${names[i]}-mobile.webp`);
  metadata[`${names[i]}-mobile`]={width:390,height:363,crown:await page.evaluate(()=>window.scene.projectCrown())};
}
await writeFile('src/render-frames.json',JSON.stringify(metadata));
await page.setViewportSize({width:1200,height:1100});
await page.evaluate(()=>window.scene.setFrame({rx:-.4,ry:-.2,rz:-.45,scale:1.03,halo:.2,screen:true,state:'resting',reduced:true}));
await page.screenshot({path:'qa/render-final.png'});await browser.close();
console.log('10 canonical model stills generated from the procedural model.');
