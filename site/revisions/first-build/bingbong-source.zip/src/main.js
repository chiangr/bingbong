import { createTimeline } from './timeline.js';
import { createInteractions } from './interactions.js';
import { assetUrl } from './assets.js';
import renderFrames from './render-frames.json';

const body=document.body;body.classList.add('enhanced');
const stage=document.querySelector('#scene-stage');
let scene,baseFrame={},interactionFrame={},chapter=0,interactions,timeline;
function apply(){const frame={...baseFrame,...interactionFrame};scene?.setFrame(frame);let point;if(scene)point=scene.projectCrown();else{const id=document.querySelectorAll('.story-section')[chapter].id;const data=renderFrames[id+(innerWidth<700?'-mobile':'')];const scale=Math.min(stage.clientWidth/data.width,stage.clientHeight/data.height);point={x:stage.clientWidth/2+(data.crown.x-data.width/2)*scale,y:stage.clientHeight/2+(data.crown.y-data.height/2)*scale};}const target=document.querySelector('#crown-target');target.style.left=`${point.x}px`;target.style.top=`${point.y}px`;}
timeline=createTimeline((frame,index,changed)=>{baseFrame=frame;chapter=index;if(changed){interactionFrame={};interactions?.reset();const section=timeline?.sections[index]??document.querySelectorAll('.story-section')[index];stage.setAttribute('aria-label',section.dataset.alt);document.querySelector('#scene-note').textContent=section.dataset.note;document.querySelector('#chapter-number').textContent=String(index+1).padStart(2,'0');document.querySelector('#chapter-name').textContent=section.dataset.label.toUpperCase();body.classList.toggle('is-halo',index===5);body.classList.toggle('is-quiet',index===7);body.classList.toggle('is-scale',index===8);stage.classList.toggle('pair-visible',index===1||index===2);document.querySelectorAll('.hero-still').forEach(img=>img.src=assetUrl(`/renders/${section.id}${img.classList.contains('hero-mobile')?'-mobile':''}.webp`));document.querySelector('#crown-target').tabIndex=[5,7,8].includes(index)?-1:0;}apply();});
interactions=createInteractions(overrides=>{interactionFrame={...overrides};apply();},()=>chapter);
// The still is the first paint. Import the 3D engine separately, then progressively enhance.
let starting=false;
const start=async()=>{if(starting)return;starting=true;const started=performance.now();try{const {createScene}=await import('./components/scene.js');scene=createScene(document.querySelector('#scene-canvas'));apply();body.classList.add('webgl-ready');document.documentElement.dataset.ready='true';performance.measure('bingbong-engagement-to-live',{start:started,end:performance.now()});}catch(error){console.info('Static product view selected:',error.message);body.classList.add('no-webgl');document.documentElement.dataset.ready='fallback';}};
// A canonical product still is immediately useful; only an interested visitor needs a GPU.
document.documentElement.dataset.ready='still';
addEventListener('scroll',()=>{if(scrollY>12)start();},{passive:true});
stage.addEventListener('pointerenter',start,{once:true});
document.addEventListener('pointerdown',start,{once:true,passive:true});
document.addEventListener('keydown',start,{once:true});
document.addEventListener('focusin',start,{once:true});
// Local QA hooks are state inspection, not a hidden product feature.
window.__bingbong={get scene(){return scene;},get chapter(){return chapter;},get frame(){return {...baseFrame,...interactionFrame};},timeline,interactions,start};
// Cache only this static app's bundled files, with no analytics, accounts or storage of gestures.
if('serviceWorker'in navigator&&!import.meta.env.DEV&&!window.__BINGBONG_ASSETS)addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
