/** The single scroll timeline. Native scroll is never cancelled or replaced.
 * All poses use one persistent assembled model. No automatic rotation, no hardware bounce.
 */
export const poses=[
  {rx:-.38,ry:-.20,rz:-.48,mobileRz:-.12,scale:1.03,y:0,screen:true,halo:.2,state:'resting',pair:0},
  {rx:-.32,ry:-.10,rz:-.26,mobileRz:-.10,scale:.78,y:24,screen:true,halo:0,state:'resting',pair:1,otherState:'resting'},
  {rx:-.32,ry:-.10,rz:-.26,mobileRz:-.10,scale:.78,y:24,screen:true,halo:0,state:'looking-up',pair:1,otherState:'resting'},
  {rx:-.25,ry:-.16,rz:-.28,mobileRz:-.10,scale:1.06,y:0,screen:true,halo:0,state:'leaning',pair:0},
  {rx:-.18,ry:-.10,rz:-.30,mobileRz:-.08,scale:1.08,y:0,screen:true,halo:0,state:'resting',pair:0},
  {rx:1.05,ry:-.14,rz:-.20,mobileRz:-.07,scale:1.05,y:0,screen:false,halo:1,state:'away',pair:0},
  {rx:-.40,ry:.1,rz:-.40,mobileRz:-.10,scale:1.03,y:0,screen:true,halo:.22,state:'resting',pair:0},
  {rx:-.48,ry:-.15,rz:-.42,mobileRz:-.12,scale:.94,y:0,screen:false,halo:0,state:'away',pair:0},
  {rx:0,ry:0,rz:0,mobileRz:0,scale:.5,y:0,screen:true,halo:0,state:'resting',pair:0},
  {rx:-.34,ry:-.18,rz:-.48,mobileRz:-.12,scale:1.02,y:0,screen:true,halo:.35,state:'resting',pair:0}
];
const lerp=(a,b,t)=>a+(b-a)*t;
const smooth=t=>t*t*(3-2*t);

export function createTimeline(onFrame) {
  const sections=[...document.querySelectorAll('.story-section')];
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let centers=[],current=-1,queued=false;
  function measure(){centers=sections.map(section=>section.offsetTop+Math.min(section.offsetHeight,innerHeight)*.5);update();}
  function update(){queued=false;
    // Each chapter has a canonical pose when its copy reaches the viewing area.
    const pos=scrollY+innerHeight*.5;let nearest=0,min=Infinity;
    centers.forEach((center,i)=>{const distance=Math.abs(pos-center);if(distance<min){min=distance;nearest=i;}});
    let next=nearest;let t=0;
    if(!reduced.matches){const d=pos-centers[nearest];next=Math.min(poses.length-1,Math.max(0,nearest+Math.sign(d)));if(next!==nearest){const span=Math.abs(centers[next]-centers[nearest]);t=smooth(Math.max(0,Math.min(1,(Math.abs(d)/span-.27)/.46)));}}
    const frame={...poses[nearest],reduced:reduced.matches};
    for(const key of ['rx','ry','rz','mobileRz','scale','y','halo'])frame[key]=lerp(poses[nearest][key],poses[next][key],t);
    if(innerWidth<700&&frame.pair)frame.y=17;
    if(nearest===8){const width=document.querySelector('#scene-stage').clientWidth;const span=innerWidth<700?112:128;frame.scale=(95/25.4*96)/(width/span*95);}
    const changed=current!==nearest;current=nearest;
    onFrame(frame,nearest,changed);
    const progress=(scrollY/(document.documentElement.scrollHeight-innerHeight))*100;
    const fill=document.querySelector('#progress-fill');fill.style[innerWidth<700?'width':'height']=`${Math.max(10,Math.min(100,progress))}%`;
    fill.style[innerWidth<700?'height':'width']='1px';
  }
  function requestUpdate(){if(!queued){queued=true;requestAnimationFrame(update);}}
  addEventListener('scroll',requestUpdate,{passive:true});addEventListener('resize',measure);reduced.addEventListener('change',measure);
  const observer=new ResizeObserver(measure);sections.forEach(section=>observer.observe(section));
  measure();return{update,measure,reduced,sections};
}
