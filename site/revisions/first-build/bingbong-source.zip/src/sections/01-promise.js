export default {
  id:'hello', label:'The promise', eyebrow:'A little closer. Wherever you are.',
  title:'You turn it.<br><em>They feel it.</em>',
  description:'A small cellular keychain, made for two. Turn the crown and your person feels every click, wherever there’s signal.',
  alt:'The assembled graphite bingbong, with a peach creature on its small black screen, a knurled silver crown and a warm halo beside the aluminium cap.',
  extra:`<p class="promise-line">No phone. No app. Nothing to set up.</p>
    <a class="primary-link" href="#pet">A little closer <span aria-hidden="true">↗</span></a>
    <div class="gesture-intro" aria-label="Three ways to reach your person">
      <a href="#pet"><span class="gesture-icon" aria-hidden="true">↻</span><span>Turn to pet</span></a>
      <a href="#boop"><span class="gesture-icon press-icon" aria-hidden="true">⊙</span><span>Press to boop</span></a>
      <a href="#hold"><span class="gesture-icon hold-icon" aria-hidden="true">∩</span><span>Hold to be there</span></a>
    </div>`,
  annotation:'A tiny gesture. A whole person on the other end.'
};
