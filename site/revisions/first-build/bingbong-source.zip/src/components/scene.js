import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { createProduct } from './product-model.js';

/** Persistent scene. .setFrame(frame) accepts timeline pose + interaction overrides.
 * .projectCrown() gives CSS coordinates for the accessible hit target.
 * Renders only on demand / while an on-screen creature or halo is moving.
 */
export function createScene(container) {
  const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power',preserveDrawingBuffer:true});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.setClearColor(0x000000,0);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;
  renderer.domElement.setAttribute('aria-hidden','true');container.append(renderer.domElement);
  const scene=new THREE.Scene();const camera=new THREE.OrthographicCamera(-70,70,70,-70,.1,1000);camera.position.set(0,0,260);camera.lookAt(0,0,0);
  const pmrem=new THREE.PMREMGenerator(renderer);const room=new RoomEnvironment();scene.environment=pmrem.fromScene(room,.04).texture;room.dispose();pmrem.dispose();scene.environmentIntensity=.9;
  const key=new THREE.DirectionalLight(0xffeee1,2.5);key.position.set(-35,70,100);scene.add(key);
  const fill=new THREE.DirectionalLight(0xf5f3ff,1.2);fill.position.set(70,-20,50);scene.add(fill);
  const rim=new THREE.DirectionalLight(0xffb99a,1.6);rim.position.set(-20,-60,-15);scene.add(rim);
  const main=createProduct(),other=createProduct();scene.add(main.group,other.group);other.group.visible=false;
  // A soft contact shadow gives mass without an expensive shadow render pass.
  const shadowCanvas=document.createElement('canvas');shadowCanvas.width=256;shadowCanvas.height=128;const ctx=shadowCanvas.getContext('2d');const shadowPixels=ctx.createImageData(256,128);
  for(let y=0;y<128;y++)for(let x=0;x<256;x++){const d=Math.sqrt(((x-128)/120)**2+((y-64)/40)**2);const k=(y*256+x)*4;shadowPixels.data[k+3]=Math.round(Math.max(0,1-d)**3*90);}ctx.putImageData(shadowPixels,0,0);
  const shadow=new THREE.Mesh(new THREE.PlaneGeometry(145,75),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(shadowCanvas),transparent:true,depthWrite:false,opacity:.8}));shadow.position.set(2,-30,-30);scene.add(shadow);
  let width=1,height=1,frame={},animation=0,disposed=false,currentHalo=0,currentOtherHalo=0,lastTime=0;
  const mobile=()=>innerWidth<700;
  function resize(){width=container.clientWidth;height=container.clientHeight;renderer.setSize(width,height);const span=mobile()?112:128;camera.left=-span/2;camera.right=span/2;camera.top=span/2*height/width;camera.bottom=-camera.top;camera.updateProjectionMatrix();draw();}
  function draw(time=0){if(disposed)return;const t=time/1000;const f=frame;const m=mobile();
    const delta=Math.min(50,Math.max(0,time-lastTime));lastTime=time;
    const approach=(from,to)=>f.reduced?to:from+Math.sign(to-from)*Math.min(Math.abs(to-from),delta/400);
    currentHalo=approach(currentHalo,f.halo??0);currentOtherHalo=approach(currentOtherHalo,f.otherHalo??0);
    main.group.rotation.set(f.rx??-.42,f.ry??-.22,m?(f.mobileRz??-.13):(f.rz??-.43));main.group.position.set(f.x??0,(f.y??0)+(m?0:2),0);main.group.scale.setScalar(f.scale??1);
    main.update({screen:f.screen!==false,halo:currentHalo*(f.reduced?1:.92+.08*Math.sin(t*Math.PI/2)),state:f.state??'resting',crown:f.crown??0,pressed:f.pressed??false,time:t,reduced:f.reduced});
    other.group.visible=(f.pair??0)>.01;
    if(other.group.visible){other.group.rotation.set(-.32,.18,m?-.13:-.3);other.group.position.set(m?4:2,m?-22:-28,-1);other.group.scale.setScalar((f.scale??1)*.87);other.update({screen:true,halo:currentOtherHalo,state:f.otherState??'resting',time:t,reduced:f.reduced,clickRate:f.clickRate??1,reaction:f.reaction??0});}
    shadow.visible=f.shadow!==false;shadow.scale.setScalar(f.scale??1);renderer.render(scene,camera);
    if(!f.reduced&&(f.screen!==false||f.halo>0||currentHalo>0||other.group.visible)&&!document.hidden)animation=requestAnimationFrame(draw);
  }
  function setFrame(next){frame={...next};cancelAnimationFrame(animation);draw(performance.now());}
  function projectCrown(){const v=new THREE.Vector3(-44,0,0).applyMatrix4(main.group.matrixWorld).project(camera);return {x:(v.x+1)/2*width,y:(1-v.y)/2*height};}
  const observer=new ResizeObserver(resize);observer.observe(container);resize();
  document.addEventListener('visibilitychange',()=>{cancelAnimationFrame(animation);if(!document.hidden)draw(performance.now());});
  return {setFrame,projectCrown,renderer,main,other,draw,dispose(){disposed=true;cancelAnimationFrame(animation);observer.disconnect();renderer.dispose();}};
}
